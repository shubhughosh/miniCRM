<?php $__env->startSection('content'); ?>

    <div class="container mt-1">
        <div class="row">
            <div class="col-8">
                <?php if(session()->has('deleted')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('deleted')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('updated')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('updated')); ?>

                    </div>
                <?php endif; ?>
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6>Manage Employee</h6>
                        <div class="table-responsive">
                            <table class="table small">
                                <thead>
                                    <tr>
                                        <th>#id</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Company</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($e->id); ?></td>
                                        <td><?php echo e($e->first_name); ?></td>
                                        <td><?php echo e($e->last_name); ?></td>
                                        <td><?php echo e($e->company); ?></td>
                                        <td><?php echo e($e->email); ?></td>
                                        <td><?php echo e($e->phone); ?></td>
                                        <td>
                                            <div class="d-flex order-actions">
                                                <a href="javascript:;" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($e->id); ?>"><i class="fas fa-edit fa-sm"></i></a>
                                                <a href="javascript:;" class="btn btn-outline-danger btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#delete<?php echo e($e->id); ?>"><i class="fas fa-trash"></i></a>
                                            </div>
                                        </td>
                                    </tr>

                                    
                                    <div class="modal fade" id="edit<?php echo e($e->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('employee.update',$e->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="staticBackdropLabel">Update Details Easily</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-gorup mb-2">
                                                            <label for="first_name" class="text-muted small m-0 p-0">First Name</label>
                                                            <input type="text" id="first_name" name="first_name" value="<?php echo e($e->first_name); ?>" class="form-control shadow-none form-control-sm">
                                                        </div>
                                                        <div class="form-gorup mb-2">
                                                            <label for="last_name" class="text-muted small m-0 p-0">Last Name</label>
                                                            <input type="text" id="last_name" name="last_name" value="<?php echo e($e->last_name); ?>" class="form-control shadow-none form-control-sm">
                                                        </div>
                                                        <div class="form-gorup mb-2">
                                                            <label for="company" class="text-muted small m-0 p-0">Company</label>
                                                            <select name="company" class="form-control shadow-none form-control-sm">
                                                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-gorup mb-2">
                                                            <label for="email" class="text-muted small m-0 p-0">Email</label>
                                                            <input type="email" id="email" name="email" value="<?php echo e($e->email); ?>" class="form-control shadow-none form-control-sm">
                                                        </div>
                                                        <div class="form-gorup mb-2">
                                                            <label for="phone" class="text-muted small m-0 p-0">Phone</label>
                                                            <input type="text" onkeypress='return event.charCode >= 48 && event.charCode <= 57' id="phone" name="phone" value="<?php echo e($e->phone); ?>" class="form-control shadow-none form-control-sm">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm shadow-none" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary btn-sm shadow-none">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="modal fade" id="delete<?php echo e($e->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <form action="<?php echo e(route('employee.destroy',$e->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="staticBackdropLabel">Confirmation</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php echo method_field('delete'); ?>
                                                        <h6>Are you sure you want to delete it?</h6>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm shadow-none" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger btn-sm shadow-none">Delete</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                            <div class="d-flex justify-content-center small">
                                <?php echo $employees->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6>Add Employee</h6>
                        <hr>
                        <form action="<?php echo e(route('employee.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-gorup mb-2">
                                <label for="first_name" class="text-muted small m-0 p-0">First Name <span class="text-danger">*</span></label>
                                <input type="text" id="first_name" name="first_name" class="form-control shadow-none form-control-sm" autofocus required>
                            </div>
                            <div class="form-gorup mb-2">
                                <label for="last_name" class="text-muted small m-0 p-0">Last Name <span class="text-danger">*</span></label>
                                <input type="text" id="last_name" name="last_name" class="form-control shadow-none form-control-sm" required>
                            </div>
                            <div class="form-gorup mb-2">
                                <label for="company" class="text-muted small m-0 p-0">Company</label>
                                <select name="company" class="form-control shadow-none form-control-sm">
                                    <option selected disabled>Select Company</option>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-gorup mb-2">
                                <label for="email" class="text-muted small m-0 p-0">Email</label>
                                <input type="email" id="email" name="email" class="form-control shadow-none form-control-sm">
                            </div>
                            <div class="form-gorup mb-2">
                                <label for="phone" class="text-muted small m-0 p-0">Phone</label>
                                <input type="text" onkeypress='return event.charCode >= 48 && event.charCode <= 57' id="phone" name="phone" class="form-control shadow-none form-control-sm">
                            </div>
                            <div class="d-grid mt-4">
                                <button type="submit" class="btn btn-primary btn-sm shadow-none" type="button">Insert</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\miniCRM\resources\views/Backend/employee.blade.php ENDPATH**/ ?>
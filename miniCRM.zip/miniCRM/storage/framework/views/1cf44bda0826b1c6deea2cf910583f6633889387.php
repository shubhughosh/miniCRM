Heyy!!
<?php /**PATH C:\Users\dell\Desktop\miniCRM\resources\views/Backend/index.blade.php ENDPATH**/ ?>